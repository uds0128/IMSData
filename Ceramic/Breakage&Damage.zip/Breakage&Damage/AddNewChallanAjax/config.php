<?php
    $servername = 'localhost';
    $username = 'root';
    $pwd = '';
    $dbname = 'imsdatabase';

    $conn = mysqli_connect($servername, $username, $pwd, $dbname);
?>